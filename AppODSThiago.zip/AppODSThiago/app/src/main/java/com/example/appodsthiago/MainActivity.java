package com.example.appodsthiago;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnODS1, btnODS2, btnODS3, btnODS4, btnODS5, btnODS6, btnODS7, btnODS8, btnODS9, btnODS10, btnODS11, btnODS12, btnODS13, btnODS14, btnODS15, btnODS16, btnODS17, btnSAIR;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnODS1 = findViewById(R.id.btnODS1);
        btnODS1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods1 = new Intent(getApplicationContext(), Ods1Activity.class);
                startActivity(ods1);
            }
        });

        btnODS2 = findViewById(R.id.btnODS2);
        btnODS2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods2 = new Intent(getApplicationContext(), Ods2Activity.class);
                startActivity(ods2);
            }
        });

        btnODS3 = findViewById(R.id.btnODS3);
        btnODS3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods3 = new Intent(getApplicationContext(), Ods3Activity.class);
                startActivity(ods3);
            }
        });

        btnODS4 = findViewById(R.id.btnODS4);
        btnODS4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods4 = new Intent(getApplicationContext(), Ods4Activity.class);
                startActivity(ods4);
            }
        });

        btnODS5 = findViewById(R.id.btnODS5);
        btnODS5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods5 = new Intent(getApplicationContext(), Ods5Activity.class);
                startActivity(ods5);
            }
        });

        btnODS6 = findViewById(R.id.btnODS6);
        btnODS6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods6 = new Intent(getApplicationContext(), Ods6Activity.class);
                startActivity(ods6);
            }
        });

        btnODS7 = findViewById(R.id.btnODS7);
        btnODS7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods7 = new Intent(getApplicationContext(), Ods7Activity.class);
                startActivity(ods7);
            }
        });

        btnODS8 = findViewById(R.id.btnODS8);
        btnODS8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods8 = new Intent(getApplicationContext(), Ods8Activity.class);
                startActivity(ods8);
            }
        });

        btnODS9 = findViewById(R.id.btnODS9);
        btnODS9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods9 = new Intent(getApplicationContext(), Ods9Activity.class);
                startActivity(ods9);
            }
        });

        btnODS10 = findViewById(R.id.btnODS10);
        btnODS10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods10 = new Intent(getApplicationContext(), Ods10Activity.class);
                startActivity(ods10);
            }
        });

        btnODS11 = findViewById(R.id.btnODS11);
        btnODS11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods11 = new Intent(getApplicationContext(), Ods11Activity.class);
                startActivity(ods11);
            }
        });

        btnODS12 = findViewById(R.id.btnODS12);
        btnODS12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods12 = new Intent(getApplicationContext(), Ods12Activity.class);
                startActivity(ods12);
            }
        });

        btnODS13 = findViewById(R.id.btnODS13);
        btnODS13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods13 = new Intent(getApplicationContext(), Ods13Activity.class);
                startActivity(ods13);
            }
        });

        btnODS14 = findViewById(R.id.btnODS14);
        btnODS14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods14 = new Intent(getApplicationContext(), Ods14Activity.class);
                startActivity(ods14);
            }
        });

        btnODS15 = findViewById(R.id.btnODS15);
        btnODS15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods15 = new Intent(getApplicationContext(), Ods15Activity.class);
                startActivity(ods15);
            }
        });

        btnODS16 = findViewById(R.id.btnODS16);
        btnODS16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods16 = new Intent(getApplicationContext(), Ods16Activity.class);
                startActivity(ods16);
            }
        });

        btnODS17 = findViewById(R.id.btnODS17);
        btnODS17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ods17 = new Intent(getApplicationContext(), Ods17Activity.class);
                startActivity(ods17);
            }
        });

        btnSAIR = findViewById(R.id.btnSAIR);
        btnSAIR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                finishAffinity();
            }
        });

    }
}